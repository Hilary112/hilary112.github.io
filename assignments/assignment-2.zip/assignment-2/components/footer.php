<?php echo '      
      <footer class="m-4">
        <p class="text-center text-muted">&copy; Assignment 2</p>
      </footer>'
?>