<?php echo '
  <ul class="nav my-nav bg-light">
  <li class="nav-item"><a class="nav-link" href="./wireframe.php">Wireframe</a></li>
    <li class="nav-item"><a class="nav-link" href="./document.php">Document</a></li>
  </ul>
';
?>